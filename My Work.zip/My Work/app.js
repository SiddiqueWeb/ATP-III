var express 		= require('express');
var ejs 			= require('ejs');
var bodyParser 		= require('body-parser');
var expressSession 	= require('express-session');
var cookieParser 	= require('cookie-parser');
var home            = require ('./controllers/home');
var login           = require ('./controllers/login');

var app = express();


//CONFIG
app.set('view engine', 'ejs');


app.use('/css',express.static('css')); 

//MIDDLEWARE
app.use(bodyParser.urlencoded({'extended': false}));
app.use(expressSession({secret: 'my top secret password', saveUninitialized: true, resave: false}));
app.use(cookieParser());



app.use('/login', login);




//ROUTING
app.get('/', function(req, res){
	res.send('Welcome to express web server...');
});


console.log(home(['siddique', 'Naim']));



//SERVER STARTUP
app.listen(1000, function(){
	console.log('Server started at 1000....');
})
