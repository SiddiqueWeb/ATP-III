<?php
	/*
	Created By Notepad++
	Name:  Md Alamin
	  ID:  16-32310-2
	*/
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="John Doe">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<title>Online School</title>
		
		<link rel="stylesheet" type="text/css" href="bootstrap/css/glyphicon.css" />
		<link rel="stylesheet" type="text/css" href="css/slider.css" />
		<link rel="stylesheet" type="text/css" href="css/mystyle.css" />
		
		
		<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
		<script type="text/javascript" src="js/jquery.dropotron-1.0.js"></script>
		<script type="text/javascript" src="js/jquery.slidertron-1.1.js"></script>
		
		
		<script type="text/javascript">
		
			$(function(){
				$('#menu > ul').dropotron({
				mode: 'fade',
				globalOffsetY: 11,
				offsetY: -15
				});
		
				$('.slider').slidertron({
				viewerSelector: '.viewer',
				indicatorSelector: '.indicator span',
				reelSelector: '.reel',
				slidesSelector: '.slide',
				speed: 'slow',
				advanceDelay: 4000
				});
			});
			
		</script>
	</head>
	<body>
		<div class="full_container">
			<div class="header_wraper">
				<div class="header container_center">
					<div class="logo">
						<a href="#"><img src="images/logo.png" alt="Logo" /></a>
						<a href="#"><h2>Online School</h2></a>
					</div>
					<div class="social_media">
						<ul>
							<li><a href="#"><img src="images/icon/facebook.png" alt="Facebook" /></a></li>
							<li><a href="#"><img src="images/icon/twitter.png" alt="Twitter" /></a></li>
							<li><a href="#"><img src="images/icon/linkedin.png" alt="LinkedIn" /></a></li>
							<li><a href="#"><img src="images/icon/youtube.png" alt="Youtube" /></a></li>
							<li><a href="#"><img src="images/icon/telegram.png" alt="Telegram" /></a></li>
							<li><a href="#"><img src="images/icon/medium.png" alt="Medium" /></a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="nav_wraper">
				<div class="nav container_center">
					<div class="menu_left">
						<ul>
							<li><a href="index.php" id="active" >Home</a></li>
							<li><a href="#">About</a></li>
							<li><a href="#">News</a></li>
							<li><a href="#">Academic</a></li>
							<li><a href="pages/Admission/admission.php">Admission</a></li>
							<li><a href="#">Course</a></li>
							<li><a href="#">Contact</a></li>
						</ul>
					</div>
					<div class="menu_right">
						<ul>
							<li><a href="pages/login.php">
							<span id="" class="glyphicon log_icon glyphicon-user"></span>
							Login</a></li>
						</ul>
					</div>
				</div>
			</div>
			
			
			<div class="slider_wraper">
				<div class="slidersection container_center">
					<div class="slider">
						<div class="viewer">
							<div class="reel">
								<div class="slide">
									<img src="images/slider/slider1.jpg" alt="" />
								</div>
								<div class="slide">
									<img src="images/slider/slider2.jpg" alt="" />
								</div>
								<div class="slide">
									<img src="images/slider/slider3.jpg" alt="" />
								</div>
								<div class="slide">
									<img src="images/slider/slider4.jpg" alt="" />
								</div>
								<div class="slide">
									<img src="images/slider/slider5.jpg" alt="" />
								</div>
							</div>
						</div>
						<div class="indicator">
							<span>1</span>
							<span>2</span>
							<span>3</span>
							<span>4</span>
							<span>5</span>
						</div>
					</div>
				</div>
			</div>
			
			<div class="content_wraper">
				<div class="content container_center">
					<div class="article1">
						<h2>Welcome To Our Website</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. <br /> <br />Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. <br /> <br />Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
					</div>
					
					<div class="article2">
						<h2>Welcome To Our Website</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborumlabore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
					</div>
				</div>
			</div>
			
			<div class="footer_wraper">
				<div class="footer">
					<div class="footer_top">
						<div class="top container_center">
							<div class="footer_top_title">
								<h3>Our Team Members</h3>
							</div>
							<div class="team">
								<div class="member">
									<img src="images/team/alamin.jpg" alt="Alamin" />
									<h3>Md Alamin <br/> Developer & Designer</h3>
									<ul>
										<li><a href="#"><img src="images/icon/facebook.png" alt="Facebook" /></a></li>
										<li><a href="#"><img src="images/icon/twitter.png" alt="Twitter" /></a></li>
										<li><a href="#"><img src="images/icon/linkedin.png" alt="LinkedIn" /></a></li>
									</ul>
								</div>
								<div class="member">
									<img src="images/team/bodrul.jpg" alt="Bodrul" />
									<h3>Bodrul Islam <br/> Designer & Developer</h3>
									<ul>
										<li><a href="#"><img src="images/icon/facebook.png" alt="Facebook" /></a></li>
										<li><a href="#"><img src="images/icon/twitter.png" alt="Twitter" /></a></li>
										<li><a href="#"><img src="images/icon/linkedin.png" alt="LinkedIn" /></a></li>
									</ul>
								</div>
								<div class="member">
									<img src="images/team/siddique.jpg" alt="Siddique" />
									<h3>Abu Bakar <br/> Manager & Designer</h3>
									<ul>
										<li><a href="#"><img src="images/icon/facebook.png" alt="Facebook" /></a></li>
										<li><a href="#"><img src="images/icon/twitter.png" alt="Twitter" /></a></li>
										<li><a href="#"><img src="images/icon/linkedin.png" alt="LinkedIn" /></a></li>
									</ul>
								</div>
							</div>
						</div>	
					</div>
					<div class="footer_bottom">
						<div class=" bottom container_center">
							<p>Copyright 2018-19 &copy; onlineschool.com <br/> &reg All Right Reserved</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>