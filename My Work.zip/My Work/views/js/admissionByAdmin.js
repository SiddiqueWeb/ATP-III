
function admission_validate() {	

	//Course Id Validation
	var result = false;
	
	if( document.admissionForm.sid.value == "") {
		document.getElementById("icon1").innerHTML = "";
		document.getElementById("error1").innerHTML = "Please, Provide Student Id";
		document.admissionForm.sid.focus();
		return false;
	} else {
		
		var sid = document.admissionForm.sid.value;
		var error = document.getElementById("error1");
		var icon = document.getElementById("icon1");
		
		//Check Course Id With Pattern
		
		var str1 = /^[1-9]{2}-[0-9]{5,8}-[1-3]{1}$/;
		var op = str1.test(sid);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			result = true;
			document.admissionForm.sname.focus();
		} else {
			error.innerHTML = "Only allow the format XX-XXXXX-X";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			
			document.admissionForm.sid.focus();
			return false;
		}	
	}

	if( document.admissionForm.sname.value == "") {
		document.getElementById("icon2").innerHTML = "";
		document.getElementById("error2").innerHTML = "Please, Provide Student Name";
		document.admissionForm.sname.focus();
		return false;
	} else {
		var sname = document.admissionForm.sname.value;
		var error = document.getElementById("error2");
		var icon = document.getElementById("icon2");
		
		//Check Course Id With Pattern
		
		var str2 = /^[a-zA-Z ]+$/;
		var op = str2.test(sname);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			result = true;
			
			document.admissionForm.semail.focus();
		} else {
			error.innerHTML = "Only allow letter & space";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";

			document.admissionForm.sname.focus();
			return false;
		}	
	}

	if( document.admissionForm.semail.value == "") {
		document.getElementById("icon3").innerHTML = "";
		document.getElementById("error3").innerHTML = "Please, Provide Student Email";
		document.admissionForm.semail.focus();
		return false;
	} else {
		var semail = document.admissionForm.semail.value;
		var error = document.getElementById("error3");
		var icon = document.getElementById("icon3");
		
		//Check Course Id With Pattern
		
		var str3 = /^[a-zA-Z0-9_]+@[a-zA-Z]+\.[a-zA-Z]{2,3}$/;
		var op = str3.test(semail);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			result = true;
		} else {
			error.innerHTML = "Invalid Email";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.admissionForm.semail.focus();
			return false;
		}	
	}
	return result;	
}



function onkeyup_sname_validation() {
	
	var sname = document.admissionForm.sname.value;
	var error = document.getElementById("error2");
	var icon = document.getElementById("icon2");
	
	if( document.admissionForm.sname.value == "" ) {
		
		error.innerHTML = "";
		icon.innerHTML = "";
		document.admissionForm.sname.focus();
		
	} else if( document.admissionForm.sname.value != "" ) {
		//Check Course Id With Pattern
		
		var str2 = /^[a-zA-Z ]+$/;
		var op = str2.test(sname);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			document.admissionForm.sname.focus();
		} else {
			error.innerHTML = "Only allow letter & space";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.admissionForm.sname.focus();
		}	
	}
}

function onkeyup_semail_validation() {
	var semail = document.admissionForm.semail.value;
	var error = document.getElementById("error3");
	var icon = document.getElementById("icon3");
	
	if( document.admissionForm.semail.value == "" ) {
		
		error.innerHTML = "";
		icon.innerHTML = "";
		document.admissionForm.semail.focus();
		
	} else if( document.admissionForm.semail.value != "" ) {
		
		var str3 = /^[a-zA-Z0-9_]+@[a-zA-Z]+\.[a-zA-Z]{2,3}$/;
		var op = str3.test(semail);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			document.admissionForm.semail.focus();
		} else {
			error.innerHTML = "Invalid Email";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.admissionForm.semail.focus();
		}	
	}
}
