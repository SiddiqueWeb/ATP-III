<?php
	session_start();
	
	$_SESSION['studentId'] = "16-32310-2";
	
	/*
	if( !isset( $_SESSION['teacherId'] ) ) {
		session_destroy();
		header("location: signin.php");
		exit();
	} else {
		echo "Login";
		echo '<a href="logout.php">Logout</a>';
	}
	*/
	
	
?>