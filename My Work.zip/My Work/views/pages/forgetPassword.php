<?php
	$email_error = $email = $info = "";
	$boolen = false;
	
	if(isset($_POST['clear'])){
		$email_error = $email = $info = "";
	}else{
		if(isset($_POST['submit'])){	
			if(empty($_POST["email"])){
				$email_error = "Email is required";
				$boolen = false;
			}else{
				$email = test_input( $_POST["email"] );
				
				if(!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)){
					$email_error = "Invalid email format";
					$boolen = false;
				}else{
					$boolen = true;
				}
			}
		}
	}
	
	if($boolen){
		require_once("dbconnection.php");
		$email = $_POST["email"];
		
		$sql = $con->query("SELECT * FROM signup WHERE email = '$email'");
		
		if($sql->num_rows > 0){
			//coding for generating token
			$token = 'hiafgestyzujklmdvnopqrwxbcEFGV1892567WOPQXYHIMNCDRSABTUZJKL340';
			$token = str_shuffle($token);
			$token = substr($token,0,8);
			
			require_once('../PHPMailer/PHPMailerAutoload.php');
			$mail = new PHPMailer();
					
			//Server settings for SMTP
			//$mail->SMTPDebug = 2;                            
			$mail->isSMTP();                                      
			$mail->Host = 'smtp.gmail.com'; 
			$mail->SMTPAuth = true;                               
			$mail->Username = 'onlineschoolbd18@gmail.com';        
			$mail->Password = 'O@S.1005';                           
			$mail->SMTPSecure = 'ssl';                         
			$mail->Port = '465';

			//Recipients settings for SMTP
					
			$mail->setFrom('onlineschoolbd18@gmail.com','Online School');
			$mail->addAddress($email);            
			/*
			$mail->addReplyTo();
			$mail->addCC();
			$mail->addBCC();
			*/
					
			//Attachments settings for SMTP
					
			/*
			$mail->addAttachment();
			$mail->addAttachment(); 
			*/
					
			//Content settings for SMTP
					
			$mail->isHTML(true);
			$mail->Subject = 'Email Confirmation';
			$mail->Body = "<h3>Your Code: ".$token."</h3>";
			//$mail->AltBody = '';
			if($mail->send()){
				$email = "";
				$info = "Please, check your email";
			}else{
				$info = "Somthing is wrong";
			}
			
		}else{
			$email_error = "Email is not registered!";
		}
	}
	
	function test_input($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="John Doe">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<title>Online School</title>
		
		<link rel="stylesheet" type="text/css" href="../bootstrap/css/glyphicon.css" />
		<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
		<link rel="stylesheet" type="text/css" href="../css/forgetPassword.css">
		
		<script type="text/javascript" src="../js/jquery-3.3.1.min.js"></script>
		
		<style>
			@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
		</style>
	</head>
	<body>
		<div class="full_container">
			<div class="header_wraper">
				<div class="header container_center">
					<div class="logo">
						<a href="#"><img src="../images/logo.png" alt="Logo" /></a>
						<a href="#"><h2>Online School</h2></a>
					</div>
					<div class="social_media">
						<ul>
							<li><a href="#"><img src="../images/icon/facebook.png" alt="Facebook" /></a></li>
							<li><a href="#"><img src="../images/icon/twitter.png" alt="Twitter" /></a></li>
							<li><a href="#"><img src="../images/icon/linkedin.png" alt="LinkedIn" /></a></li>
							<li><a href="#"><img src="../images/icon/youtube.png" alt="Youtube" /></a></li>
							<li><a href="#"><img src="../images/icon/telegram.png" alt="Telegram" /></a></li>
							<li><a href="#"><img src="../images/icon/medium.png" alt="Medium" /></a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="forget_password">
				<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
					<div class="pass_reset_form">
						<div class="form_title">
							<h3>Password Reset Form</h3>
						</div>
						<span id="error_msg"><?php echo $info;?></span>
						
						<div class="content2 content_area">
							<input type="text" name="email" id="txtemail" placeholder="Enter Email" value="<?php echo $email;?>" />
							<span id="c1" class="glyphicon icon glyphicon-envelope"></span>
						</div>
						<span id="error_msg"><?php echo $email_error;?></span>
							
						<div class="content3">
							<input type="submit" name="submit" value="Submit" />
							<input type="submit" name="clear" value="Clear" id="" />
						</div>
						
						<div class="back_home">
							<a href="../index.php">Back Home</a>
						</div>
					</div>
				</form>
				
				<script>
					$(document).ready(function(){
						var icon="";
						var $txt1 = $("txtemail");
						
						$("input").focus(function(){
							var id = document.activeElement.id;
							
							
							if(id=="txtemail"){
								$("#c1").css("color","green");
								icon = "#c1";
							}
						});
						
						$("input").blur(function(){
							$(icon).css("color","#b2b2b2");
						});
					});
				</script>
				
			</div>
			
			<div class="container">
			</div>
			<div class="footer_wraper">
				<div class="footer container_center">
					<div class="footer_top">
					</div>
					<div class="footer_bottom">
						<p>Copyright 2018-19 &copy; onlineschool.com <br/> &reg All Right Reserved</p>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>