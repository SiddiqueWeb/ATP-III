<?php
	session_start();
	
	if( isset( $_SESSION['studentId'] ) ) {
		session_destroy();
		header( "location: signin.php" );
		exit();
	} else {
		if( isset( $_SESSION['teacherId'] ) ) {
			session_destroy();
			header( "location: signin.php" );
			exit();
		} else {
			session_destroy();
			header( "location: signin.php" );
			exit();
		}
	}
?>