<?php
	
	$username_error = $email_error = $pass_error = $cpass_error = $name_error = $gender_error = $check_error = $img_error = $info = "";
	
	$username = $email = $password = $cpassword = $name = $fileNewName = "";
	
	$boolen = false;
	$agree = false;
	
	
	if( isset( $_POST['submit'] ) ) {
		if( $_POST['submit'] == "Submit" ) {
			
			if( empty( $_POST["name"] ) ) {
				$name_error = "Name is required";
				$boolen = false;
			} else {
				$name = test_input( $_POST["name"] );
				$name_error = "";
				$boolen = true;
			}
			
			if( empty( $_POST["username"] ) ) {
				$username_error = "Username is required";
				$boolen = false;
			} else {
				$username = test_input( $_POST["username"] );
				$username_error = "";
				if( $boolen ) {
					$boolen = true;
				} else {
					$boolen = false;
				}
			}
			
			if( empty( $_POST["email"] ) ) {
				$email_error = "Email is required";
				$boolen = false;
			} else {
				$email = test_input( $_POST["email"] );
				$email_error = "";
				
				if( $boolen ) {
					$boolen = true;
				} else {
					$boolen = false;
				}
			}		
					
			if( empty( $_POST["password"] ) ) {
				$pass_error = "Password is required";
				$boolen = false;
			} else {
				$str = $_POST["password"];
				$passln = strlen( $str );
				
				if( $passln > 10 || $passln < 5){
					$pass_error = "Password Should be between 5 & 10";
					$boolen = false;
				}else{
					$password = test_input( $_POST["password"] );
					$pass_error = "";
					
					if($boolen){
						$boolen = true;
					}else{
						$boolen = false;
					}
				}
			}
					
			if( empty( $_POST["cpassword"] ) ) {
				$cpass_error = "Password is required";
				$boolen = false;
			} elseif( $_POST["cpassword"] != $password ) {
				$cpass_error = "Password don't match!";
				$boolen = false;
			} else {
				$cpassword = test_input( $_POST["cpassword"] );
				$cpass_error = "";
				
				if( $boolen ) {
					$boolen = true;
				} else {
					$boolen = false;
				}
			}
			
			if( empty( $_POST["gender"] ) ) {
				$gender_error = "Gender is required";
				$boolen = false;
			} else {
				$gender = test_input($_POST["gender"]);
				$gender_error = "";
				
				if( $boolen ) {
					$boolen = true;
				} else {
					$boolen = false;
				}
			}
					
			if( isset( $_POST["check1"] ) && isset( $_POST["check2"] ) ) {
				$check_error = "";
				$agree = true;
			} else {
				$check_error = "Do you agree with this Conditions?";
				$agree = false;
			}
		}
	}
	
	if( $boolen ) {
		if( $agree ) {
			require_Once("../dbconnection.php");
			Registration();
		}
	}
	
	function Registration() {
		$username = $_POST["username"];
		$email = $_POST["email"];
				
		$query = oci_parse( $GLOBALS['con'], "SELECT * FROM admission WHERE USERNAME = '$username'" );
		oci_execute( $query );
		$data = oci_fetch_array( $query );	
		
		if( oci_num_rows( $query ) > 0 ) {
			$GLOBALS['username_error'] = "Username Exist!";
		} else {
			require_Once("newuser.php");
			Photo();
			NewUser();
		}	
	}
	
	function test_input($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="John Doe">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<title>Online School</title>
		
		<link rel="stylesheet" type="text/css" href="../../css/mystyle.css">
		<link rel="stylesheet" type="text/css" href="../../css/Admission/admission.css">
		<link rel="stylesheet" type="text/css" href="../../css/Admission/registration.css">
		<script type="text/javascript" src="../../js/registration.js" ></script>
	</head>
	<body>
		<div class="full_container">
			<div class="header_wraper">
				<div class="header container_center">
					<div class="logo">
						<a href="#"><img src="../../images/logo.png" alt="Logo" /></a>
						<a href="#"><h2>Online School</h2></a>
					</div>
					<div class="social_media">
						<ul>
							<li><a href="#"><img src="../../images/icon/facebook.png" alt="Facebook" /></a></li>
							<li><a href="#"><img src="../../images/icon/twitter.png" alt="Twitter" /></a></li>
							<li><a href="#"><img src="../../images/icon/linkedin.png" alt="LinkedIn" /></a></li>
							<li><a href="#"><img src="../../images/icon/youtube.png" alt="Youtube" /></a></li>
							<li><a href="#"><img src="../../images/icon/telegram.png" alt="Telegram" /></a></li>
							<li><a href="#"><img src="../../images/icon/medium.png" alt="Medium" /></a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="nav_wraper">
				<div class="nav container_center">
					<div class="menu_left">
						<ul>
							<li><a href="../../index.php">Home</a></li>
							<li><a href="#">About</a></li>
							<li><a href="#">News</a></li>
							<li><a href="#">Academic</a></li>
							<li><a href="admission.php">Admission</a></li>
							<li><a href="#">Course</a></li>
							<li><a href="#">Contact</a></li>
						</ul>
					</div>
					<div class="admission_menu_right">
						<ul>
							<li><a href="registration.php" id="active" >Registration</a></li>
							<li><a href="signin.php">SignIn</a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="Registration_wraper">
				<form name="registration" action="registration.php" method="post" onsubmit="return registration_validation()" enctype="multipart/form-data" >
					<div class="registration_form">
						<div class="form_title">
							<h3>Registration Form</h3>
						</div>
						<span id="msg"><?php echo $info;?></span>
						
						<div class="form_content">
							
							<div class="content_area">
								<input type="text" name="name" placeholder="Enter Your Name" oninput="oninput_name_validation()" onkeyup="onkeyup_name_validation()" value="<?php echo $name;?>" />
								<span id="icon1"></span>
							</div>
							<span id="error1"><?php echo $name_error;?></span>
							
							<div class="content_area">
								<input type="text" name="username" placeholder="Enter Username" oninput="oninput_username_validation()" onkeyup="onkeyup_username_validation()" value="<?php echo $username;?>" />
								<span id="icon2"></span>
							</div>
							<span id="error2"><?php echo $username_error;?></span>
							
							<div class="content_area">
								<input type="text" name="email" placeholder="Enter Email" oninput="oninput_email_validation()" onkeyup="onkeyup_email_validation()" value="<?php echo $email;?>" />
								<span id="icon3"></span>
							</div>
							<span id="error3"><?php echo $email_error;?></span>
							
							<div class="content_area">
								<input type="password" name="password" placeholder="Enter Password" oninput="oninput_password_validation()" onkeyup="onkeyup_password_validation()" value="<?php echo $password;?>" />
								<span id="icon4"></span>
							</div>
							<span id="error4"><?php echo $pass_error;?></span>
							
							<div class="content_area">
								<input type="password" name="cpassword" placeholder="Confirm Password" oninput="oninput_cpassword_validation()" onkeyup="onkeyup_cpassword_validation()" value="<?php echo $cpassword;?>" />
								<span id="icon5"></span>
							</div>
							<span id="error5"><?php echo $cpass_error;?></span>
							
							<div class="content6">
								<h3>Gender:</h3>
								<input type="radio" name="gender" value="male" /> <label for="">Male</label>
								<input type="radio" name="gender" value="female" /> <label for="">Female</label>
								<input type="radio" name="gender" value="other" /> <label for="">Other</label>
							</div>
							<span id="error_msg"><?php echo $gender_error;?></span>
							
							<div class="content9">
								<input type="file" name="photo" />
								
							</div>
							<span id="error_msg"><?php echo $img_error;?></span>
							
							<div class="content7">
								<input type="checkbox" name="check1" value="" id="" />
								<span id="ck1" >I read All Policies & Rules</span> <br/>
								<input type="checkbox" name="check2" value="" id="" />
								<span id="ck1" >I Agree With Privacy & Policies </span>
							</div>
							<span id="error_msg"><?php echo $check_error;?></span>
							
							<div class="content8">
								<input type="submit" name="submit" value="Submit" />
								<input type="submit" name="reset" value="Reset" id="" />
							</div>
						</div>
					</div>
				</form>
			</div>
			
			<div class="container">
			</div>
			<div class="footer_wraper">
				<div class="footer">
					<div class="footer_top">
					</div>
					<div class="footer_bottom">
						<div class=" bottom container_center">
							<p>Copyright 2018-19 &copy; onlineschool.com <br/> &reg All Right Reserved</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>