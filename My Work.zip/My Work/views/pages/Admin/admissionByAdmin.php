<?php

	$name = $photo = $info = "";
	require("adminAccountAccess.php");
	
	$id_error = $name_error = $email_error = "";
	$sname = $semail = $sid = "";

	require_once("../dbconnection.php");
	
	$sql = oci_parse( $con, "select Max(STUDENT_ID) MID from student_login" );
	
	oci_execute( $sql);
	
	$data = oci_fetch_array( $sql );
	
	if( oci_num_rows( $sql ) > 0 ) {
		$temId = $data['MID'];
		
		$id_array = array();
		$sub_id = preg_split( "/-/", $temId );
		$i = 0;
	
		foreach( $sub_id as $temp ) {
			$id_array[$i] = $temp;
			$i++;
		}
		
		if( strlen( $id_array[1] ) == 5 ) {
			++$id_array[1];
			
			$sid = $id_array[0]."-".$id_array[1]."-".$id_array[2];
		}
	} else {
		$sid = "19-12132-1";
	}
	
	$boolen = false;
	
	if( isset( $_POST['submit'] ) ) {
		if( $_POST['submit'] == "Submit" ) {
			
			if( empty( $_POST["sid"] ) ) {
				$id_error = "id is required";
				$boolen = false;
			}
				
			if( empty( $_POST["sname"] ) ) {
				$name_error = "Name is required";
				$boolen = false;
			} else {
				$sname = test_input( $_POST["sname"] );
				
				if( !preg_match( "/^[a-zA-Z ]+$/", $sname ) ) {
					$name_error = "Only allow characters & space"; 
					$boolen = false;
				} else {
					$name_error = "";
					$boolen = true;
				}
			}
			
			if( empty( $_POST["semail"] ) ) {
				$email_error = "Email is required";
				$boolen = false;
			}else{
				$semail = test_input( $_POST["semail"] );
				
				if( !preg_match( "/^[a-zA-Z0-9_]+@[a-zA-Z]+\.[a-zA-Z]{2,3}$/", $semail ) ) {
					$email_error = "Invalid Email"; 
					$boolen = false;
				} else {
					$email_error = "";
					
					if( $boolen ) {
						$boolen = true;
					} else {
						$boolen = false;
					}	
				}
			}
		}
	}
	
	if( $boolen ) {
		require_once("../dbconnection.php");
		Admission();
	}
	
	function Admission() {
		$id = $_POST['sid'];
		$name = $_POST['sname'];
		$email = $_POST['semail'];
		
		$query2 = oci_parse( $GLOBALS['con'], "INSERT INTO student_login( S_T_ID, STUDENT_ID, ST_NAME, ST_EMAIL ) VALUES( STUDENT_LOGIN_ID_SEQU.NEXTVAL, '$id', '$name', '$email' )" );
			
		$res1 = oci_execute( $query2 );
		$id_error = $name_error = $email_error = "";
	$sname = $semail = $sid = "";
			
		if( $res1 ) {
			$GLOBALS['id_error'] = $GLOBALS['name_error'] = $GLOBALS['email_error'] = "";
			$GLOBALS['sname'] = $GLOBALS['semail'] = $GLOBALS['sid'] = "";
			$GLOBALS['boolen'] = false;
			$GLOBALS['info'] = "Admission Successfull";
		} else {
			$GLOBALS['id_error'] = $GLOBALS['name_error'] = $GLOBALS['email_error'] = "";
			$GLOBALS['sname'] = $GLOBALS['semail'] = $GLOBALS['sid'] = "";
			$GLOBALS['boolen'] = false;
			$GLOBALS['info'] = "Admission Fail! Try Again";
		}
	}
	
	function test_input( $data ) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta charset="UTF-8">
		<title>Online School - Admin</title>
		<link rel="stylesheet" href="../../css/Admin/admin.css" />
		<link rel="stylesheet" href="../../css/Admin/admissionByAdmin.css" />
		
		<script type="text/javascript" src="../../js/admissionByAdmin.js"></script>
	</head>
	<body>
		<div class="full_container">
			<div class="admin_header_wraper">
				<div class="admin_header container_center">
					<div class="admin_logo">
						<a href="#"><img src="../../images/logo.png" alt="Logo" /></a>
						<a href="#"><h2>Online School Portal</h2></a>
					</div>
					
					<div class="admin_menu_icon">
						<ul>
							<li style="margin-top: -3px;"><a href="admissionByAdmin.php" id="active_top" style="font-size: 21px;">&#x2756 Admission</a></li>
							<li><a href="addCourse.php">&#x2724 Add Course</a></li>
							<li><a href="#">&#x2724 Add Batch</a></li>
							<li><a href="">&#x274B Change Password</a></li>
							<li><a href="../logout.php" style="font-size: 26px;padding-top: 3px;" title="Logout">&#x27A5</a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="content_wraper">
				<div class="content container_center">
					<div class="content_left">
						<div class="admin_photo">
						<!--	<img src="../images/profiles/<?php echo $photo;?>" alt="Profile Photo" /> -->
							<img src="../../images/profiles/megh.jpg" alt="Profile Photo" />
						</div>
						
						<div class="admin_name">
							<p>Welcome, <?php echo $name;?></P>
						</div>
						
						<div class="admin_menu_section">
							<ul>
								<li><a href="admin.php" >My Account</a></li>
								<li><a href="#">Add Teacher</a></li>
								<li><a href="#">Add Teacher To Course</a></li>
								<li><a href="#">View Course List</a></li>
								<li><a href="viewTeacherList.php">View Teacher List</a></li>
								<li><a href="viewStudentList.php">View Student List</a></li>
								<li><a href="#">Profile</a></li>
								<li><a href="#">Message</a></li>
								<li><a href="../logout.php">Logout</a></li>
							</ul>
						</div>
					</div>
					
					<div class="content_right">
						<div class="admission_wraper">
							<form name="admissionForm" method="post" onsubmit="return admission_validate()" action="admissionByAdmin.php" >
								<div class="admission_form">
									<div class="admission_form_title">
										<h3>Admission Form</h3>
										<p>Please fill in this form to admit</p>
									</div>
									<span id="msg"><?php echo $info;?></span>
									
									<div class="form_content">
										<div class="content_area">
											<input type="text" name="sid" placeholder="Enter Name" value="<?php echo $sid;?>" />
											<span id="icon1"></span>
										</div>
										<span id="error1"><?php echo $id_error;?></span>
										
										<div class="content_area">
											<input type="text" name="sname" placeholder="Enter Name" value="<?php echo $sname;?>" onkeyup="onkeyup_sname_validation()" autofocus />
											<span id="icon2"></span>
										</div>
										<span id="error2"><?php echo $name_error;?></span>
										
										<div class="content_area">
											<input type="text" name="semail" placeholder="Enter Email" value="<?php echo $semail;?>" onkeyup="onkeyup_semail_validation()" />
											<span id="icon3"></span>
										</div>
										<span id="error3"><?php echo $email_error;?></span>
										
										<div class="content1" >
											<input type="submit" name="submit" value="Submit" />
											<input type="reset" name="reset" value="Reset" />
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			
			<div class="footer_wraper">
				<div class="footer container_center">
					<div class="footer_top">
					</div>
					<div class="footer_bottom">
						<p>Copyright 2018-19 &copy; onlineschool.com <br/> &reg All Right Reserved</p>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>