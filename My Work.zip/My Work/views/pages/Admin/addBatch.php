<?php
	session_start();
	
	$name = $photo = "";
	/*
	if(!isset($_SESSION['username'])){
		session_destroy();
		header("location: admin.php");
		exit();
	}else{
		*/
		require_once("dbconnection.php");
		//$email = $_SESSION['username'];
		
		$sql = $con->query("SELECT * FROM signup WHERE username = '$email'");
		
		if($sql->num_rows > 0){
			$data = $sql->fetch_array();
			$name = $data['name'];
			$photo = $data['photo'];
			
		}else{
			$name = "Wrong";
		}
	//}

	
	$batchId_error = $course_error = $courseId_error = $course_teacher_error = $schedule_error = $info = "";

	$batchId = $course = $courseId = $course_teacher = $schedule = "";
	
	$boolen = false;
	$agree = false;
	
	if(isset($_POST['reset'])){
		$batchId = $course = $courseId = $course_teacher = $schedule = "";
	}else{
		if($_SERVER["REQUEST_METHOD"] == "POST"){
		
			if(empty($_POST["batchId"])){
				$batchId_error = "Batch Id is required";
				$boolen = false;
			}else{
				$batchId = test_input( $_POST["batchId"] );
				$batchId_error = "";
				$boolen = true;
			}
			
			if(empty($_POST["course"])){
				$course_error = "Course Name is required";
				$boolen = false;
			}else{
				$course = test_input( $_POST["course"] );
				$course_error = "";
				$boolen = true;
			}

			if(empty($_POST["courseId"])){
				$courseId_error = "Course Id is required";
				$boolen = false;
			}else{
				$courseId = test_input( $_POST["courseId"] );
				$courseId_error = "";
				$boolen = true;
			}

			if(empty($_POST["course_teacher"])){
				$course_teacher_error = "Teacher Name is required";
				$boolen = false;
			}else{
				$course_teacher = test_input( $_POST["course_teacher"] );
				$course_teacher_error = "";
				$boolen = true;
			}
			if(empty($_POST["schedule"])){
				$schedule_error = "Schedule is required";
				$boolen = false;
			}else{
				$schedule = test_input( $_POST["schedule"] );
				$schedule_error = "";
				$boolen = true;
			}
		}
	}
	
	if($boolen){
		$dbname = "registration";
		$con = mysqli_connect("localhost","root","",$dbname);
					
		if(!$con){
			die("Connection Failed:" + mysqli_connect_error());
		}
			
		function AddBatch(){				
				$batchId = $_POST["batchId"];
				$course = $_POST["course"];
				$courseId = $_POST["courseId"];
				$course_teacher = $_POST["course_teacher"];
				$schedule = $_POST["schedule"];
				
				
				$sql = $GLOBALS['con']->query("INSERT INTO addbatch(batch_id,course,course_id,course_teacher,schedule) VALUES('$batchId','$course','$courseId','$course_teacher','$schedule')");
						
				//$query = mysqli_query($GLOBALS['con'],$sql);
						
				if($sql){
					
						$GLOBALS['addbatch'] = $GLOBALS['batchId'] = $GLOBALS['course'] = $GLOBALS['courseId'] = $GLOBALS['course_teacher'] = $GLOBALS['schedule'] = "";
					
						$GLOBALS['boolen'] = false;
						$GLOBALS['agree'] = false;
						$GLOBALS['info'] = "Batch Add Successfull!";
				}else{
					$GLOBALS['addbatch'] = $GLOBALS['batchId'] = $GLOBALS['course'] = $GLOBALS['courseId'] = $GLOBALS['course_teacher'] = $GLOBALS['schedule'] = "";
					
					$GLOBALS['boolen'] = false;
					$GLOBALS['agree'] = false;
					$GLOBALS['info'] = "Batch Add Failed! Try Again";
				}
			}

		if(isset($_POST["submit"])){
			AddBatch();
			mysqli_close($GLOBALS['con']);
			$boolen = false;
		}else{
			$GLOBALS['info'] = "Something is wrong!";
		}
	}
	
	function test_input($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
?>



<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="description" content="Free Web tutorials">
	<meta name="keywords" content="HTML,CSS,XML,JavaScript">
	<meta name="author" content="John Doe">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
	<title>Add Batch | <?php echo $name;?></title>

	<link rel="stylesheet" href="../css/adminstyle.css" />	
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/glyphicon.css" />	
	<script type="text/javascript" src="../js/jquery-3.3.1.min.js"></script>	
	<script type="text/javascript" src="../js/addBatch.js"></script>		
	<style>
		@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');

		#batchId_error{
			color: #ff0000;
			margin: 85px;    
			font-size: 16px;
    		color: #ffffff;
		}
		#course_error{
			color: #ff0000;
			margin: 85px;    
			font-size: 16px;
    		color: #ffffff;
		}
		#courseId_error{
			color: #ff0000;
			margin: 85px;    
			font-size: 16px;
    		color: #ffffff;
		}
		#course_teacher_error{
			color: #ff0000;
			margin: 85px;    
			font-size: 16px;
    		color: #ffffff;
		}
		#schedule_error{
			color: #ff0000;
			margin: 85px;    
			font-size: 16px;
    		color: #ffffff;
		}
	</style>
</head>
<body>
	<div class="full_container">
		<div class="admin_header_wraper">
			<div class="admin_header">
				<div class="admin_logo">
					<a href="#"><img src="../images/logo.png" alt="Logo" /></a>
					<a href="#"><h2>Online School Portal</h2></a>
				</div>
				<div class="admin_menu_top">
					<!--<ul>
						<li><a href="#">&#x2630 Courses & Results</a></li>
						<li><a href="#">&#x27A4 Registration</a></li>
						<li><a href="#">&#x2738 Grade Report</a></li>
					</ul>-->
				</div>
				<div class="admin_menu_icon">
					<ul>
						<li><a href="changepassword.php">&#x274B Change Password</a></li>
						<li><a href="logout.php" style="font-size: 26px;padding-top: 3px;" title="Logout">&#x27A5</a></li>
					</ul>
				</div>
			</div>
		</div>
		
		<div class="content_wraper">
			<div class="content_left">
				<div class="admin_photo">
					<img src="../images/profiles/<?php echo $photo;?>" alt="Profile Photo" />
				</div>
				<div class="admin_name">
					<p>Welcome, <?php echo $name;?></P>
				</div>
				<div class="admin_menu_section">
					<ul>
						<li><a href="admin.php">My Account</a></li>
						<li><a href="addBatch.php">Add Batch</a></li>
						<li><a href="addCourse.php">Add Course</a></li>
						<li><a href="addTeacher.php">Add Teacher</a></li>
						<li><a href="addTeachertoCourse.php">Add Teacher To Course</a></li>
						<li><a href="addStudenttoCourse.php">Add Student To Course</a></li>
						<li><a href="viewTeacherList.php">View Teacher List</a></li>
						<li><a href="viewStudentList.php">View Student List</a></li>
						<li><a href="adminProfile.php">Profile</a></li>
						<li><a href="message.php">Message</a></li>
						<li><a href="changepassword.php">Change Password</a></li>
					</ul>
				</div>
			</div>
			<div class="content_right">
				<div class="addBatch_wraper">
					<form id="addBatchForm" name="addBatchForm" method="post" enctype="multipart/form-data" onsubmit="return addBatch_validate()" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
						<div class="addBatch_form">
							<div class="addBatch_form_title">
								<h3>Add Batch</h3>
								<p>Please fill in this form to Add a new Batch.</p>
								<span id="submit_info"><?php echo $info;?></span>
							</div>
							<div class="addBatch_form_content">
								<div class="content1 addBatch_content_area">
									<input type="text" name="batchId" id="txtbatchid" placeholder="Enter Batch Id" value="" />
									<span id="c1" class="glyphicon adminicon glyphicon-plus"></span>
								</div>
									<span id="batchId_error"></span>
									<!--<span id="error_msg"><?php echo $batchId_error;?></span>-->

								<div class="content2 addBatch_content_area">
									<input type="text" name="course" id="txtcourse" placeholder="Enter Course" value="" />
									<span id="c2" class="glyphicon adminicon glyphicon-plus"></span>
								</div>
									<span id="course_error"></span>
									<!--<span id="error_msg"><?php echo $course_error;?></span>-->

								<div class="content3 addBatch_content_area">
									<input type="text" name="courseId" id="txtcourseid" placeholder="Enter Course Id" value="" />
									<span id="c3" class="glyphicon adminicon glyphicon-plus"></span>
								</div>
									<span id="courseId_error"></span>
									<!--<span id="error_msg"><?php echo $courseId_error;?></span>-->
															
								<div class="content4 addBatch_content_area">
									<input type="text" name="course_teacher" id="txtcourseteacher" placeholder="Enter Course Teacher" value="" />
									<span id="c4" class="glyphicon adminicon glyphicon-user"></span>
								</div>
									<span id="course_teacher_error"></span>
									<!--<span id="error_msg"><?php echo $course_teacher_error;?></span>-->

								<div class="content5 addBatch_content_area">
									<input type="text" name="schedule" id="txtschedule" placeholder="Enter Schedule" value="" />
									<span id="c5" class="glyphicon adminicon glyphicon-time"></span>
								</div>
									<span id="schedule_error"></span>
									<!--<span id="error_msg"><?php echo $schedule_error;?></span>-->
								
								<div class="content8">
									<input type="submit" name="submit" value="Submit" />
									<input type="reset" name="reset" value="Reset" id="" />
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="footer">
			<div class="footer_top">
			</div>
			<div class="footer_bottom">
				<p>Copyright 2018-19 &copy; onlineschool.com <br/> &reg All Right Reserved</p>
			</div>
		</div>
	</div>
</body>
</html>