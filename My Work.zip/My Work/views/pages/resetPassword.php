<?php
	$pass_error = $cpass_error = $info = "";
	$password = $cpassword = "";
	$boolen = false;
	
	if(isset($_POST['clear'])){
		$pass_error = $cpass_error = $info = "";
		$password = $cpassword = "";
	}else{
		if(isset($_POST['submit'])){
			if(empty($_POST["password"])){
				$pass_error = "Password is required";
				$boolen = false;
			}else{
				$str = $_POST["password"];
				$passln = strlen($str);
							
				if($passln > 15){
					$pass_error = "Password Should be less than 15 charecters";
					$boolen = false;
								
				}elseif($passln < 5 && $passln >= 1){
					$pass_error = "Password Should be greater than 6 charecters";
					$boolen = false;
				}else{
					$password = test_input($_POST["password"]);
					$pass_error = "";
					if($boolen){
						$boolen = true;
					}else{
						$boolen = false;
					}
				}
			}
			if(empty($_POST["cpassword"])){
				$cpass_error = "Confirm Password is required";
				$boolen = false;
			}elseif($_POST["cpassword"] != $password){
				$cpass_error = "Password don't match!";
				$boolen = false;
			}else{
				$cpassword = test_input($_POST["cpassword"]);
				$cpass_error = "";
				if($boolen){
					$boolen = true;
				}else{
					$boolen = false;
				}
			}
		}else{
			if(!isset($_GET['username']) && !isset($_GET['token'])){
				header('location: signup.php');
				exit();
			}
		}
	}
	
	
	function test_input($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="John Doe">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<title>Online School</title>
		
		<link rel="stylesheet" type="text/css" href="../bootstrap/css/glyphicon.css" />
		<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
		<link rel="stylesheet" type="text/css" href="../css/resetPassword.css">
		
		<script type="text/javascript" src="../js/jquery-3.3.1.min.js"></script>
		
		<style>
			@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
		</style>
	</head>
	<body>
		<div class="full_container">
			<div class="header">
				<div class="logo">
					<a href="#"><img src="../images/logo.png" alt="Logo" /></a>
					<a href="#"><h2>Online School</h2></a>
				</div>
				<div class="social_media">
					<ul>
						<li><a href="#"><img src="../images/facebook.png" alt="Facebook" /></a></li>
						<li><a href="#"><img src="../images/twitter.png" alt="Twitter" /></a></li>
						<li><a href="#"><img src="../images/linkedin.png" alt="LinkedIn" /></a></li>
						<li><a href="#"><img src="../images/youtube.png" alt="Youtube" /></a></li>
					</ul>
				</div>
			</div>
			
			<div class="reset_password">
				<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
					<div class="pass_reset_form">
						<span id="error_msg"><?php echo $info;?></span>
						
						<div class="content_area">
							<input type="password" name="password" id="txtpass" placeholder="Enter New Password" value="<?php echo $password;?>" />
							<span id="c1" class="glyphicon icon glyphicon-lock"></span>
						</div>
						<span id="error_msg"><?php echo $pass_error;?></span>
							
						<div class="content_area">
							<input type="password" name="cpassword" id="txtcpass" placeholder="Confirm Password" value="<?php echo $cpassword;?>" />
							<span id="c2" class="glyphicon icon glyphicon-lock"></span>
						</div>
						<span id="error_msg"><?php echo $cpass_error;?></span>
							
						<div class="content3">
							<input type="submit" name="submit" value="Submit" />
							<input type="submit" name="clear" value="Clear" />
						</div>
						
						<div class="back_home">
							<a href="../index.php">Back Home</a>
						</div>
					</div>
				</form>
				
				<script>
					$(document).ready(function(){
						var icon="";
						var $txt1 = $("txtpass");
						var $txt2 = $("txtcpass");
						
						$("input").focus(function(){
							var id = document.activeElement.id;
							
							
							if(id=="txtpass"){
								$("#c1").css("color","green");
								icon = "#c1";
							}
							
							if(id=="txtcpass"){
								$("#c2").css("color","green");
								icon = "#c2";
							}
						});
						
						$("input").blur(function(){
							$(icon).css("color","#b2b2b2");
						});
					});
				</script>
				
			</div>
			
			<div class="container">
			</div>
			<div class="footer">
				<div class="footer_top">
				</div>
				<div class="footer_bottom">
					<p>Copyright 2018-19 &copy; onlineschool.com <br/> &reg All Right Reserved</p>
				</div>
			</div>
		</div>
	</body>
</html>