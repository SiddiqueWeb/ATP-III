var db = require('./db');

module.exports = {

	getById: function(StudentId, callback){
		var sql = "select * from student where id="+StudentId;
		db.getResult(sql, function(result){
			callback(result);
		});
	},
	getAll: function(id,callback){
		var sql = "select * from student where StudentId='"+id+"'" ;
		db.getResult(sql, function(results){
			callback(results);
		});	
	},
	getPassword: function(id,callback){
		var sql = "select password from student where StudentId='"+id+"'";
		db.getResult(sql, function(results){
			callback(results);
		});	
	},
	
	validate: function(student, callback){

		var sql = "select * from student where StudentId='"+student.StudentId+"' and password='"+student.password+"'";
		db.getResult(sql, function(results){

			if(results.length > 0){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	create: function(student, callback){
		var sql = "insert into student ('','"+student.StudentId+"','"+student.password+"')";
		db.execute(sql, function(status){
			callback(status);
		});
	},
	update: function(student, callback){
		var sql = "update student set password='"+student.password+"' where id="+student.StudentId;
		db.execute(sql, function(status){
			callback(status);
		});
	},
	delete: function(studentId, callback){
		var sql = "delete from student where id="+StudentId;
		db.execute(sql, function(status){
			callback(status);
		});
	}
}