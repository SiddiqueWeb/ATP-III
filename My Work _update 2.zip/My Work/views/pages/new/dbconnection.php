<?php 
	$con = oci_connect( "onlineschool", "os2018", "localhost/orcl" );
	
	if ( !$con ) {    
		$error_msg = oci_error();    
		trigger_error( 'Could not connect to database: '.$error_msg['message'],E_USER_ERROR ); 
	}
?>