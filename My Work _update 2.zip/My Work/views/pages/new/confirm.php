<?php

	if( !isset( $_GET['email'] ) && !isset( $_GET['token'] ) ) {
		header( 'location: Admission/registration.php' );
		exit();
	} else {
		$email = $_GET['email'];
		$token = $_GET['token'];
		
		require_once('dbconnection.php');
		
		$query = oci_parse( $con, "SELECT USERNAME FROM admission WHERE EMAIL = '$email' AND TOKEN = '$token' AND ISEMAILCONFIRM = 0" );
		oci_execute( $query );
		
		$data = oci_fetch_array( $query );
			
		if( oci_num_rows( $query ) > 0 ) {
			$user = $data['USERNAME'];
			require_once('dbconnection.php');
			
			$query1 = oci_parse( $con, "UPDATE admission SET  ISEMAILCONFIRM = 1, TOKEN = '' WHERE USERNAME = '$user' " );
			$sql = oci_execute( $query1 );
			
			if( $sql ) {
				echo 'You are verified.You can login';
				echo "<a href='Admission/signin.php'>SignIn</a>";
			} else {
				echo 'Verification Fail! Try Again';
			}
			
		} else {
			echo 'You are not registered';
		}
	}
?>