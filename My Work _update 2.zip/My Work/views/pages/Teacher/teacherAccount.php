<?php
	session_start();
	
	$name = $photo = "";
	
	if( !isset( $_SESSION['teacherId'] ) ) {
		session_destroy();
		header("location: signin.php");
		exit();
	} else {
		require_once( "dbconnection.php" );
		$id = $_SESSION['teacherId'];
		
		$query = oci_parse( $con, "SELECT * FROM teacher_login WHERE TEACHER_ID = '$id'" );
		oci_execute( $query );
		$data = oci_fetch_array( $query );
		
		if( oci_num_rows( $query ) > 0 ) {
			$name = $data['TEC_NAME'];
			$photo = $data['TEC_PHOTO'];
		} else {
			header( "location: signin.php" );
			exit();
		}
	}
?>


<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Registration</title>
	<link rel="stylesheet" href="../css/myaccount.css" />
	
	<style>
		@import url('https://fonts.googleapis.com/css?family=Source+Sans+Pro');
	</style>
</head>
<body>
	<div class="full_container">
		<div class="account_header_wraper">
			<div class="account_header">
				<div class="account_logo">
					<a href="#"><img src="../images/logo.png" alt="Logo" /></a>
					<a href="#"><h2>Online School Portal</h2></a>
				</div>
				<div class="account_menu_top">
					<ul>
						<li><a href="#">&#x2630 Courses & Results</a></li>
						<li><a href="#">&#x27A4 Registration</a></li>
						<li><a href="#">&#x2738 Grade Report</a></li>
					</ul>
				</div>
				<div class="account_menu_icon">
					<ul>
						<li><a href="#">&#x274B Change Password</a></li>
						<li><a href="logout.php" style="font-size: 26px;padding-top: 3px;" title="Logout">&#x27A5</a></li>
					</ul>
				</div>
			</div>
		</div>
		
		<div class="content_wraper">
			<div class="content_left">
				<div class="client_photo">
					<img src="../images/profiles/<?php echo $photo;?>" alt="Profile Photo" />
				</div>
				<div class="client_name">
					<p>Welcome, <?php echo $name;?></P>
				</div>
				<div class="client_menu_section">
					<ul>
						<li><a href="">My Account</a></li>
						<li><a href="">Registration</a></li>
						<li><a href="">My Curriculam</a></li>
						<li><a href="">Finacials</a></li>
						<li><a href="">Course</a></li>
						<li><a href="">Results</a></li>
						<li><a href="">Profile</a></li>
						<li><a href="">Message</a></li>
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</div>
			</div>
			<div class="content_right">
			</div>
		</div>
		<div class="footer">
			<div class="footer_top">
			</div>
			<div class="footer_bottom">
				<p>Copyright 2018-19 &copy; onlineschool.com <br/> &reg All Right Reserved</p>
			</div>
		</div>
	</div>
</body>
</html>