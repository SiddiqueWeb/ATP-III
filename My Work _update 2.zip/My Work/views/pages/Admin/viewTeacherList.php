<?php
	$name = $photo = "";
	require("adminAccountAccess.php");
	require_once("../dbconnection.php");
	$query1 = oci_parse( $con, "SELECT * FROM teacher_login" );
	oci_execute( $query1 );
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="John Doe">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<title>Online School - Teacher List</title>

		<link rel="stylesheet" href="../../css/Admin/admin.css" />
		<link rel="stylesheet" href="../../css/Admin/teacherList.css" />
	</head>
	
	<body>
		<div class="full_container">
			<div class="admin_header_wraper">
				<div class="admin_header container_center">
					<div class="admin_logo">
						<a href="#"><img src="../../images/logo.png" alt="Logo" /></a>
						<a href="#"><h2>Online School Portal</h2></a>
					</div>
					
					<div class="admin_menu_icon">
						<ul>
							<li><a href="#">&#x2756 Admission</a></li>
							<li><a href="addCourse.php">&#x2724 Add Course</a></li>
							<li><a href="#">&#x2724 Add Batch</a></li>
							<li><a href="">&#x274B Change Password</a></li>
							<li><a href="../logout.php" style="font-size: 26px;padding-top: 3px;" title="Logout">&#x27A5</a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="content_wraper">
				<div class="content container_center">
					<div class="content_left">
						<div class="admin_photo">
							<img src="../../images/profiles/<?php echo $photo;?>" alt="Profile Photo" />
						</div>
						<div class="admin_name">
							<p>Welcome, <?php echo $name;?></P>
						</div>
						<div class="admin_menu_section">
							<ul>
								<li><a href="admin.php">My Account</a></li>
								<li><a href="#">Add Teacher</a></li>
								<li><a href="#">Add Teacher To Course</a></li>
								<li><a href="#">View Course List</a></li>
								<li><a href="#" id="active">View Teacher List</a></li>
								<li><a href="viewStudentList.php">View Student List</a></li>
								<li><a href="#">Profile</a></li>
								<li><a href="#">Message</a></li>
								<li><a href="../logout.php">Logout</a></li>
							</ul>
						</div>
					</div>
					<div class="content_right">
						<div class="teacherList_wraper">
							<div class="teacherList_table">
								<div class="teacher_list_title">
									<h3>Teacher List of Online School</h3>
								</div>
								<table class="teacher_list">
									<tr>
										<th class="list_table_header" >Serial</th>
										<th class="list_table_header" >ID</th>
										<th class="list_table_header" >Name</th>										
										<th class="list_table_header" >Email</th>								
										<th class="list_table_header" >Action</th>
									</tr>
									
									<?php
										while( $data = oci_fetch_array( $query1 ) ) {
										$serial = $data['T_T_ID'];
										$id= $data['TEACHER_ID'];
										$name= $data['TEC_NAME'];
										$email= $data['TEC_EMAIL'];
									?>
									
									<tr class="row_val" >
										<td class="info_col" ><?php echo $serial;?></td>
										<td class="info_col" ><?php echo $id;?></td>
										<td class="info_col" ><?php echo $name;?></td>
										<td class="info_col" ><?php echo $email;?></td>
										<td class="info_col" >
											<a class="action" href="">View</a>
											<a class="action" href="">Delete</a>
											<a class="action" href="">Update</a>
										</td>
									</tr> 
									<?php } ?>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="footer_wraper">
				<div class="footer container_center">
					<div class="footer_top">
					</div>
					<div class="footer_bottom">
						<p>Copyright 2018-19 &copy; onlineschool.com <br/> &reg All Right Reserved</p>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>