
<?php
	session_start();
	
	if( !isset( $_SESSION['adminId'] ) ) {
		session_destroy();
		header("location: ../signin.php");
		exit();
	} else {
		require_once( "../dbconnection.php" );
		$id = $_SESSION['adminId'];
		
		$query = oci_parse( $con, "SELECT * FROM admin_login WHERE ADMIN_ID = '$id'" );
		oci_execute( $query );
		$data = oci_fetch_array( $query );
		
		if( oci_num_rows( $query ) > 0 ) {
			$name = $data['ADMIN_NAME'];
			$photo = $data['ADMIN_PHOTO'];
		} else {
			header( "location: ../signin.php" );
			exit();
		}
	}
?>