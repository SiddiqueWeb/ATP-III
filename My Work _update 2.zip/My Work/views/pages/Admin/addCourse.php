<?php

	$name = $photo = $info = "";
	
	require("adminAccountAccess.php");
	
	$courseId_error = $course_name_error = $course_credit_error = "";
	$courseId = $courseName = $courseCredit = "";
	
	
	$boolen = false;
	
	if( isset( $_POST['submit'] ) ) {
		if( $_POST['submit'] == "Submit" ) {
			
			if( empty( $_POST["courseId"] ) ) {
				$courseId_error = "Course Id is required";
				$boolen = false;
			} else {
				$courseId = test_input( $_POST["courseId"] );
				
				if( !preg_match( "/^[0-9]{3}$/", $courseId ) ) {
					$courseId_error = "Course Id should be numeric & length at least 3"; 
					$boolen = false;
				} else {
					$courseId_error = "";
					$boolen = true;
				}
			}
			
			if( empty( $_POST["course"] ) ) {
				$course_name_error = "Course Name is required";
				$boolen = false;
			}else{
				$courseName = test_input( $_POST["course"] );
				
				if( !preg_match( "/^[a-zA-Z ]/", $courseName ) ) {
					$course_name_error = "Only allow chracters & space"; 
					$boolen = false;
				} else {
					$course_name_error = "";
					
					if( $boolen ) {
						$boolen = true;
					} else {
						$boolen = false;
					}	
				}
			}
			
			if( empty( $_POST["courseCredit"] ) ) {
				$course_credit_error = "Course Credit is required";
				$boolen = false;
			} else {
				$courseCredit = test_input( $_POST["courseCredit"] );
				
				if( !preg_match( "/^[0-9]{1}$/", $courseCredit ) ) {
					$course_credit_error = "Only allow number"; 
					$boolen = false;
				} else {
					$course_credit_error = "";
					
					if( $boolen ) {
						$boolen = true;
					} else {
						$boolen = false;
					}
				}
			}
		}
	}

	if( $boolen ) {
		require_once("../dbconnection.php");
		AddCourse();
	}
	
	function AddCourse() {
			
		$c_id = $_POST["courseId"];				
		$c_name = $_POST["course"];
		$credit = $_POST["courseCredit"];
		$time = 1.5;
		$dno = 10;
			
		$query = oci_parse( $GLOBALS['con'], "INSERT INTO course( C_T_ID, COURSE_ID, COURSE_NAME, COURSE_CREDIT, COURSE_DURATION, DEPARTMENT_NO) VALUES( AUTO_COURSE_T_ID.NEXTVAL, '$c_id', '$c_name', '$credit', $time, $dno)" );
			
		$res = oci_execute( $query );
			
		if( $res ) {
					
			$GLOBALS['courseId'] = $GLOBALS['courseName'] = $GLOBALS['courseCredit'] = "";
			$GLOBALS['courseId_error'] = $GLOBALS['course_name_error'] = $GLOBALS['course_credit_error'] = "";
					
			$GLOBALS['boolen'] = false;
			$GLOBALS['info'] = "Course Add Successfully";
		} else {
			$GLOBALS['courseId'] = $GLOBALS['courseName'] = $GLOBALS['courseCredit'] = "";
			$GLOBALS['courseId_error'] = $GLOBALS['course_name_error'] = $GLOBALS['course_credit_error'] = "";
					
			$GLOBALS['boolen'] = false;
			$GLOBALS['info'] = "Failed! Try Again";
		}
	}
	
	
	function test_input( $data ) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	
?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="John Doe">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
			
		<title>Online School - Add Course</title>

		<link rel="stylesheet" href="../../css/Admin/admin.css" />	
		<link rel="stylesheet" href="../../css/Admin/addCourse.css" />	
		<script type="text/javascript" src="../../js/addCourse.js"></script>		
	</head>
	<body>
		<div class="full_container">
			<div class="admin_header_wraper">
				<div class="admin_header container_center">
					<div class="admin_logo">
						<a href="#"><img src="../../images/logo.png" alt="Logo" /></a>
						<a href="#"><h2>Online School Portal</h2></a>
					</div>
		
					<div class="admin_menu_icon">
						<ul>
							<li><a href="admissionByAdmin.php">&#x2756 Admission</a></li>
							<li><a href="#" id="active_top" style="font-size: 21px;" >&#x2724 Add Course</a></li>
							<li><a href="#">&#x2724 Add Batch</a></li>
							<li><a href="">&#x274B Change Password</a></li>
							<li><a href="../logout.php" style="font-size: 26px;padding-top: 3px;" title="Logout">&#x27A5</a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="content_wraper">
				<div class="content container_center">
					<div class="content_left">
						<div class="admin_photo">
							<img src="../../images/profiles/<?php echo $photo;?>" alt="Profile Photo" />
						</div>
						<div class="admin_name">
							<p>Welcome, <?php echo $name;?></P>
						</div>
						<div class="admin_menu_section">
							<ul>
								<li><a href="admin.php">My Account</a></li>
								<li><a href="#">Add Teacher</a></li>
								<li><a href="#">Add Teacher To Course</a></li>
								<li><a href="#">Add Student To Course</a></li>
								<li><a href="viewTeacherList.php">View Teacher List</a></li>
								<li><a href="viewStudentList.php">View Student List</a></li>
								<li><a href="#">Profile</a></li>
								<li><a href="#">Message</a></li>
								<li><a href="../logout.php">Logout</a></li>
							</ul>
						</div>
					</div>
					
					<div class="content_right">
						<div class="addCourse_wraper">
							<form name="addCourseForm" method="post" onsubmit="return addCourse_validate()" action="addCourse.php" >
								<div class="addCourse_form">
									<div class="addCourse_form_title">
										<h3>Add Course</h3>
										<p>Please fill in this form to Add a new Course.</p>
									</div>
									<span id="msg"><?php echo $info;?></span>
									
									<div class="addCourst_form_content">
										<div class="content_area">
											<input type="text" name="courseId" placeholder="Enter Course Id" onkeyup="onkeyup_cid_validation()" />
											<span id="icon1" ></span>
										</div>
										<span id="error1"><?php echo $courseId_error;?></span>
																	
										<div class="content_area">
											<input type="text" name="course" placeholder="Enter Course Name" onkeyup="onkeyup_cname_validation()" />
											<span id="icon2" ></span>
										</div>
										<span id="error2"></span><?php echo $course_name_error;?></span>

										<div class="content_area">
											<input type="text" name="courseCredit" placeholder="Enter Course Credit" onkeyup="onkeyup_credit_validation()" />
											<span id="icon3" ></span>
										</div>
										<span id="error3"><?php echo $course_credit_error;?></span>
									
										<div class="content1" >
											<input type="submit" name="submit" value="Submit" />
											<input type="reset" name="reset" value="Reset" />
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			<div class="footer_wraper">
				<div class="footer container_center">
					<div class="footer_top">
					</div>
					<div class="footer_bottom">
						<p>Copyright 2018-19 &copy; onlineschool.com <br/> &reg All Right Reserved</p>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>