<?php

	$name = $photo = "";
	require("adminAccountAccess.php");
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta charset="UTF-8">
		<title>Online School - Admin</title>
		<link rel="stylesheet" href="../../css/Admin/admin.css" />
	</head>
	<body>
		<div class="full_container">
			<div class="admin_header_wraper">
				<div class="admin_header container_center">
					<div class="admin_logo">
						<a href="#"><img src="../../images/logo.png" alt="Logo" /></a>
						<a href="#"><h2>Online School Portal</h2></a>
					</div>
					
					<div class="admin_menu_icon">
						<ul>
							<li style="margin-top: -2px;" ><a href="admissionByAdmin.php" onclick="onclick_admission_validate();">&#x2756 Admission</a></li>
							<li><a href="addCourse.php">&#x2724 Add Course</a></li>
							<li><a href="#">&#x2724 Add Batch</a></li>
							<li><a href="">&#x274B Change Password</a></li>
							<li><a href="../logout.php" style="font-size: 26px;padding-top: 3px;" title="Logout">&#x27A5</a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="content_wraper">
				<div class="content container_center">
					<div class="content_left">
						<div class="admin_photo">
						<!--	<img src="../images/profiles/<?php echo $photo;?>" alt="Profile Photo" /> -->
							<img src="../../images/profiles/megh.jpg" alt="Profile Photo" />
						</div>
						
						<div class="admin_name">
							<p>Welcome, <?php echo $name;?></P>
						</div>
						
						<div class="admin_menu_section">
							<ul>
								<li><a href="#" id="active">My Account</a></li>
								<li><a href="#">Add Teacher</a></li>
								<li><a href="#">Add Teacher To Course</a></li>
								<li><a href="#">View Course List</a></li>
								<li><a href="viewTeacherList.php">View Teacher List</a></li>
								<li><a href="viewStudentList.php">View Student List</a></li>
								<li><a href="#">Profile</a></li>
								<li><a href="#">Message</a></li>
								<li><a href="../logout.php">Logout</a></li>
							</ul>
						</div>
					</div>
					
					<div class="content_right">
					</div>
				</div>
			</div>
			
			<div class="footer_wraper">
				<div class="footer container_center">
					<div class="footer_top">
					</div>
					<div class="footer_bottom">
						<p>Copyright 2018-19 &copy; onlineschool.com <br/> &reg All Right Reserved</p>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>