<?php
	
	function NewUser() {
		$user = $_POST["username"];
		$email = $_POST["email"];
		$pass = md5( $_POST["password"] );
		$name = $_POST["name"];
		$gender = $_POST["gender"];
		$image = $GLOBALS['fileNewName'];
				
		//coding for generating token
		$token = 'hiafgestyzujklmdvnopqrwxbcEFGVWOPQXYHIMNCDRSABTUZJKL3401892567';
		$token = str_shuffle( $token );
		$token = substr( $token, 0, 10 );	
		
		require_Once("../dbconnection.php");
		
		$query = oci_parse( $GLOBALS['con'], "INSERT INTO admission( A_T_ID, USERNAME, EMAIL, PASS, UNAME, PHOTO, GENDER, TOKEN ) VALUES( ADMISSION_T_ID.nextval, '$user', '$email', '$pass', '$name', '$image', '$gender', '$token' ) ");
		$res = oci_execute( $query );				
		
		if( $res ) {		
			//$lin = "localhost/Online School/pages/confirm.php?email=".$email."&token=".$token;
			//$body = '<p>Please click on the link below for verification:</p><br/><a>'.$lin.'</a>';
			
			require_once('../../PHPMailer/PHPMailerAutoload.php');
			$mail = new PHPMailer();
					
			//Server settings for SMTP
					                          
			$mail->isSMTP();                                      
			$mail->Host = 'smtp.gmail.com'; 
			$mail->SMTPAuth = true;                               
			$mail->Username = 'onlineschoolbd18@gmail.com';        
			$mail->Password = 'O@S.1005';                           
			$mail->SMTPSecure = 'ssl';                         
			$mail->Port = '465';

			//Recipients settings for SMTP
					
			$mail->setFrom('onlineschoolbd18@gmail.com','Online School');
			$mail->addAddress($email);            
					
			//Content settings for SMTP
			$mail->isHTML(true);
			$mail->Subject = 'Email Verification';
			$mail->Body = "Please, verify your email by click below link <br/><br/>
			
			<a href='localhost/DataBase/pages/confirm.php?email=$email&token=$token'>localhost/DataBase/pages/confirm.php?email=$email&token=$token</a> <br/><br/>
			
			Best regrads,<br/>
			Online School
			";
					
			if( $mail->send() ) {
				$GLOBALS['username'] = $GLOBALS['email'] = $GLOBALS['password'] = $GLOBALS['cpassword'] =
				$GLOBALS['name'] = $GLOBALS['gender'] = $GLOBALS['fileNewName'] = "";
					
				$GLOBALS['boolen'] = false;
				$GLOBALS['agree'] = false;
				$GLOBALS['info'] = "Registration Successfull! Please, verify your email";
			} else {
				$GLOBALS['username'] = $GLOBALS['email'] = $GLOBALS['password'] = $GLOBALS['cpassword'] =
				$GLOBALS['name'] = $GLOBALS['gender'] = $GLOBALS['fileNewName'] = "";
					
				$GLOBALS['boolen'] = false;
				$GLOBALS['agree'] = false;
				$GLOBALS['info'] = "Registration Failed! EMAIL NOT SEND";
			}
			
		} else {
			$GLOBALS['username'] = $GLOBALS['email'] = $GLOBALS['password'] = $GLOBALS['cpassword'] =
			$GLOBALS['name'] = $GLOBALS['gender'] = $GLOBALS['fileNewName'] = "";
					
			$GLOBALS['boolen'] = false;
			$GLOBALS['agree'] = false;
			$GLOBALS['info'] = "Registration Failed! Try Again";
		}
	}
	
	function Photo() {
		//coding for image processing
		$fileName = $_FILES['photo']['name'];
		$fileError = $_FILES['photo']['error'];
		$fileSize = $_FILES['photo']['size'];
		$fileTmpName = $_FILES['photo']['tmp_name'];
					
		//image extension collector coding 
		$fileExtension = explode( '.', $fileName );
		$fileActualExt = strtolower( end( $fileExtension ) );
		$validExtension = array('jpg','jpeg','png','pdf');
					
		//coding for image coditions checking
		if( in_array( $fileActualExt, $validExtension ) ) {
			if( $fileError == 0 ) {
				if( $fileSize < 1000000 ) {
					$GLOBALS['fileNewName'] = $GLOBALS['username'].".".$fileActualExt;
					$directory = "../../images/profiles/".basename( $GLOBALS['fileNewName'] );
					move_uploaded_file( $fileTmpName, $directory );
				} else {
					$GLOBALS['msg_error'] = "File Size large too";
				}
			} else {
				$GLOBALS['msg_error'] = "There is error to upload";
			}
		} else {
			$GLOBALS['msg_error'] = "The image type is invalid!";
		}
	}
?>