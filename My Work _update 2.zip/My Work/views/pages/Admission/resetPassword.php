<?php
	session_start();
	$pass_error = $cpass_error = $info = "";
	$password = $cpassword = "";
	$boolen = false;
	
	if( isset( $_POST['clear'] ) ) {
		$pass_error = $cpass_error = $info = "";
		$password = $cpassword = "";
	} else {
		if( isset( $_POST['submit'] ) ) {
			
			if( empty( $_POST["password"] ) ) {
				$pass_error = "New Password is required";
				$boolen = false;
			} else {
				$str = $_POST["password"];
				$passln = strlen($str);
							
				if( $passln > 10 || $passln < 5 ) {
					$pass_error = "Password Should be between 5 & 10";
					$boolen = false;
				} else {
					$password = test_input( $_POST["password"] );
					$pass_error = "";
					$boolen = true;
				}
			}
			
			if( empty( $_POST["cpassword"] ) ) {
				$cpass_error = "Confirm Password is required";
				$boolen = false;
			} elseif( $_POST["cpassword"] != $password ) {
				$cpass_error = "Password don't match!";
				$boolen = false;
			} else {
				$cpassword = test_input( $_POST["cpassword"] );
				$cpass_error = "";
				
				if( $boolen ) {
					$boolen = true;
				} else {
					$boolen = false;
				}
			}
			
		}else{
			
			if( !isset( $_GET['email'] ) || !isset( $_GET['token'] ) ) {
				header( 'location: registration.php' );
				exit();
			} else {
				
				$email = $_GET['email'];
				$token = $_GET['token'];
				$_SESSION['email'] = $email;
				$_SESSION['token'] = $token;
			}
		}
	}
	
	if( $boolen ) {
		$email = $_SESSION['email'];
		$token = $_SESSION['token'];
		$pass = md5( $_POST['password'] );
		
		require_once("../dbconnection.php");
		
		$query = oci_parse( $con, "SELECT * FROM admission WHERE EMAIL = '$email'" );
		oci_execute( $query );
		$data = oci_fetch_array( $query );
		
		if( oci_num_rows( $query ) > 0 ) {
			if( $token == $data['TOKEN'] ) {
				require_once("../dbconnection.php");
				
				$query1 = oci_parse( $con, "UPDATE admission SET  PASS = '$pass', TOKEN = '' WHERE EMAIL = '$email'" );
				$sql = oci_execute( $query1 );
				
				if( $sql ) {
					session_destroy();
					$info = "Password is successfully changed"; 
				} else {
					$info = "Password is not changed"; 
				}
			} else {
				$info = "Somthing wrong"; 
			}
		} else {
			$info = "You are not registered!"; 
		}
	}
	
	function test_input($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="John Doe">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<title>Online School - Reset Password</title>
		
		<link rel="stylesheet" type="text/css" href="../../css/mystyle.css">
		<link rel="stylesheet" type="text/css" href="../../css/Admission/resetPassword.css">
		
	</head>
	<body>
		<div class="full_container">
			<div class="header_wraper">
				<div class="header container_center">
					<div class="logo">
						<a href="#"><img src="../../images/logo.png" alt="Logo" /></a>
						<a href="#"><h2>Online School</h2></a>
					</div>
					<div class="social_media">
						<ul>
							<li><a href="#"><img src="../../images/icon/facebook.png" alt="Facebook" /></a></li>
							<li><a href="#"><img src="../../images/icon/twitter.png" alt="Twitter" /></a></li>
							<li><a href="#"><img src="../../images/icon/linkedin.png" alt="LinkedIn" /></a></li>
							<li><a href="#"><img src="../../images/icon/youtube.png" alt="Youtube" /></a></li>
							<li><a href="#"><img src="../../images/icon/telegram.png" alt="Telegram" /></a></li>
							<li><a href="#"><img src="../../images/icon/medium.png" alt="Medium" /></a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="reset_password">
				<form action="resetPassword.php" method="post">
					<div class="pass_reset_form">
						<div class="form_title">
							<h3>Password Reset Form</h3>
						</div>
						<span id="msg"><?php echo $info;?></span>
						
						<div class="content_area">
							<input type="password" name="password" placeholder="Enter New Password" value="<?php echo $password;?>" />
							<span id="icon1" ></span>
						</div>
						<span id="error1"><?php echo $pass_error;?></span>
							
						<div class="content_area">
							<input type="password" name="cpassword" placeholder="Confirm Password" value="<?php echo $cpassword;?>" />
							<span id="icon2" ></span>
						</div>
						<span id="error2"><?php echo $cpass_error;?></span>
							
						<div class="content3">
							<input type="submit" name="submit" value="Submit" />
							<input type="submit" name="clear" value="Clear" />
						</div>
						
						<div class="back_home">
							<a href="../../index.php">Back Home</a>
						</div>
					</div>
				</form>
			</div>
			
			<div class="container">
			</div>
			<div class="footer">
				<div class="footer_top">
				</div>
				<div class="footer_bottom">
					<div class=" bottom container_center">
						<p>Copyright 2018-19 &copy; onlineschool.com <br/> &reg All Right Reserved</p>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>