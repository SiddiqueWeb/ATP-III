<?php
	session_start();
	
	$name = $photo = "";
	
	if( !isset( $_SESSION['email'] ) ) {
		session_destroy();
		header("location: signin.php");
		exit();
	} else {
		echo "Login";
	}
?>