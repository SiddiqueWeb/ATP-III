<?php
	session_start();
	$email_error = $pass_error = $info = "";
	$email = $password = "";
	
	$boolen = false;
	
	if( isset( $_POST['submit'] ) ) {
		if( $_POST['submit'] == "Submit" ) {
			
			if( empty( $_POST["email"] ) ) {
				$email_error = "Email is required";
				$boolen = false;
			} else {
				$email = test_input( $_POST["email"] );
				$email_error = "";
				$boolen = true;
			}
				
			if( empty( $_POST["password"] ) ) {
				$pass_error = "Password is required";
				$boolen = false;
			} else {
				$password = test_input( $_POST["password"] );
				$pass_error = "";
				
				if( $boolen ) {
					$boolen = true;
				} else {
					$boolen = false;
				}
			}
		}
	}
	
	
	if( $boolen ) {
		require_Once("../dbconnection.php");
		SignIn();
	}
	
	function SignIn() {
		
		$email = $_POST["email"];
		$pass = md5( $_POST["password"] );
		
		$sql = oci_parse( $GLOBALS['con'], "SELECT * FROM admission WHERE EMAIL = '$email'" );
		oci_execute( $sql );
		
		$data = oci_fetch_array( $sql );
		
		if( oci_num_rows( $sql ) > 0 ) {
			if( $data['ISEMAILCONFIRM'] == 1 ) {
				
				if( $email == $data["EMAIL"] && $pass == $data['PASS'] ) {
					$_SESSION['email'] = $email;
					header("location: account.php");
				} else {
					$GLOBALS['email'] = $GLOBALS['password'] = "";
					$GLOBALS['email_error'] = $GLOBALS['pass_error'] = "";
					$GLOBALS['boolen'] = false;
					$GLOBALS['info'] = "Email or Password is wrong!";
				}
				
			} else {
				$GLOBALS['info'] = "Please, verify your email";
			}
		} else {
				$GLOBALS['email'] = $GLOBALS['password'] = "";
				$GLOBALS['email_error'] = $GLOBALS['pass_error'] = "";
				$GLOBALS['boolen'] = false;
				$GLOBALS['info'] = "You are not registered";
		}
	}
			
	
	function test_input( $data ) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="John Doe">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<title>Online School</title>
		
		<link rel="stylesheet" type="text/css" href="../../css/mystyle.css">
		<link rel="stylesheet" type="text/css" href="../../css/Admission/admission.css">
		<link rel="stylesheet" type="text/css" href="../../css/Admission/signin.css">
	</head>
	<body>
		<div class="full_container">
			<div class="header_wraper">
				<div class="header container_center">
					<div class="logo">
						<a href="#"><img src="../../images/logo.png" alt="Logo" /></a>
						<a href="#"><h2>Online School</h2></a>
					</div>
					<div class="social_media">
						<ul>
							<li><a href="#"><img src="../../images/icon/facebook.png" alt="Facebook" /></a></li>
							<li><a href="#"><img src="../../images/icon/twitter.png" alt="Twitter" /></a></li>
							<li><a href="#"><img src="../../images/icon/linkedin.png" alt="LinkedIn" /></a></li>
							<li><a href="#"><img src="../../images/icon/youtube.png" alt="Youtube" /></a></li>
							<li><a href="#"><img src="../../images/icon/telegram.png" alt="Telegram" /></a></li>
							<li><a href="#"><img src="../../images/icon/medium.png" alt="Medium" /></a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="nav_wraper">
				<div class="nav container_center">
					<div class="menu_left">
						<ul>
							<li><a href="../../index.php">Home</a></li>
							<li><a href="#">About</a></li>
							<li><a href="#">News</a></li>
							<li><a href="#">Academic</a></li>
							<li><a href="admission.php">Admission</a></li>
							<li><a href="#">Course</a></li>
							<li><a href="#">Contact</a></li>
						</ul>
					</div>
					<div class="admission_menu_right">
						<ul>
							<li><a href="registration.php">Registration</a></li>
							<li><a href="signin.php" id="active" >SignIn</a></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="signin_wraper">
				<form action="signin.php" method="post">
					<div class="signin_form">
						<div class="form_title">
							<h3>Admission SignIn Form</h3>
						</div>
						<span id="msg"><?php echo $info;?></span>
						
						<div class="form_content">
							<div class="content_area">
								<input type="text" name="email" placeholder="Enter Email" value="<?php echo $email;?>" />
								<span id="icon1"></span>
							</div>
							<span id="error1"><?php echo $email_error;?></span>
							
							<div class="content_area">
								<input type="password" name="password" placeholder="Enter Password" value="<?php echo $password;?>" />
								<span id="icon2"></span>
							</div>
							<span id="error2"><?php echo $pass_error;?></span>
							
							<div class="content3">
								<input type="submit" name="submit" value="Submit" />
								<input type="submit" name="reset" value="Reset" id="" />
							</div>
							<div class="forget_pass_link">
								<a href="forgetPassword.php">Forget Password?</a>
							</div>
						</div>
					</div>
				</form>
			</div>
			
			<div class="container">
			</div>
			<div class="footer_wraper">
				<div class="footer">
					<div class="footer_top">
					</div>
					<div class="footer_bottom">
						<div class=" bottom container_center">
							<p>Copyright 2018-19 &copy; onlineschool.com <br/> &reg All Right Reserved</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>