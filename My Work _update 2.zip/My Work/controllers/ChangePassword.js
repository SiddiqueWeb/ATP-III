var express = require('express');
var user	= require.main.require('./models/user-model');
var router = express.Router();

router.get('/', function(req, res){
	
	var id= "16-32308-2";

	user.getPassword(id,function(results){

		if(results != null){
			// console.log(results[0].password);
			res.render('pages/ChangePassword',{oldpassword: results});
		}else{
			res.send('Error!.. try again...');
		}
	});

});






module.exports = router ;